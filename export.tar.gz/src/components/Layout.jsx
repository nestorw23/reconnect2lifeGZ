
import React from "react"
import { Outlet } from "react-router-dom"
import BottomNav from "@/components/BottomNav"

function Layout() {
  return (
    <div className="min-h-screen pb-16">
      <Outlet />
      <BottomNav />
    </div>
  )
}

export default Layout
