
import React from "react"
import { Routes, Route } from "react-router-dom"
import Register from "@/pages/Register"
import Home from "@/pages/Home"
import Psychometrics from "@/pages/Psychometrics"
import Sessions from "@/pages/Sessions"
import Profile from "@/pages/Profile"
import Layout from "@/components/Layout"

function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/register" element={<Register />} />
        <Route path="/psychometrics" element={<Psychometrics />} />
        <Route path="/sessions" element={<Sessions />} />
        <Route path="/profile" element={<Profile />} />
      </Route>
    </Routes>
  )
}

export default App
