
import React, { useState } from "react"
import { useNavigate } from "react-router-dom"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"

function Register() {
  const navigate = useNavigate()
  const { toast } = useToast()
  const [selectedRole, setSelectedRole] = useState(null)
  const [username, setUsername] = useState("")
  const [showUsernameInput, setShowUsernameInput] = useState(false)

  const roles = [
    { 
      id: "consumer", 
      label: "Persona en Recuperación", 
      description: "Estoy buscando apoyo para mi proceso de recuperación" 
    },
    { 
      id: "family", 
      label: "Familiar", 
      description: "Estoy apoyando a un ser querido en su recuperación" 
    },
    { 
      id: "therapist", 
      label: "Terapeuta", 
      description: "Soy un profesional ayudando a otros en su recuperación" 
    },
  ]

  const handleRoleSelect = (role) => {
    setSelectedRole(role)
  }

  const handleContinue = () => {
    if (!selectedRole) {
      toast({
        title: "Por favor selecciona un rol",
        description: "Necesitas seleccionar un rol para continuar",
        variant: "destructive",
      })
      return
    }
    setShowUsernameInput(true)
  }

  const handleUsernameSubmit = () => {
    if (!username.trim()) {
      toast({
        title: "Por favor ingresa un nombre de usuario",
        description: "Necesitas ingresar un nombre de usuario para continuar",
        variant: "destructive",
      })
      return
    }

    const userData = {
      role: selectedRole,
      username: username.trim(),
      hasSetObjective: false
    }

    localStorage.setItem("user", JSON.stringify(userData))
    navigate("/")
  }

  return (
    <div className="min-h-screen pb-16">
      <div className="p-6 flex flex-col items-center justify-center">
        <div className="w-full max-w-md space-y-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-primary">ReConnect2Life</h1>
            <p className="mt-2 text-muted-foreground">
              Tu camino hacia la recuperación comienza aquí
            </p>
          </div>

          {!showUsernameInput ? (
            <>
              <div className="space-y-4">
                <h2 className="text-xl font-semibold">Elige tu rol:</h2>
                {roles.map((role) => (
                  <motion.div
                    key={role.id}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <button
                      className={`w-full p-4 rounded-lg border ${
                        selectedRole?.id === role.id
                          ? "border-primary bg-primary/10"
                          : "border-border hover:border-primary/50"
                      } text-left transition-all`}
                      onClick={() => handleRoleSelect(role)}
                    >
                      <h3 className="font-medium">{role.label}</h3>
                      <p className="text-sm text-muted-foreground">
                        {role.description}
                      </p>
                    </button>
                  </motion.div>
                ))}
              </div>

              <Button
                className="w-full"
                size="lg"
                onClick={handleContinue}
              >
                Continuar
              </Button>
            </>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              <h2 className="text-xl font-semibold">Ingresa tu nombre de usuario:</h2>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full p-2 border rounded-md"
                placeholder="Nombre de usuario"
                autoFocus
              />
              <Button
                className="w-full"
                size="lg"
                onClick={handleUsernameSubmit}
              >
                Comenzar
              </Button>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  )
}

export default Register
